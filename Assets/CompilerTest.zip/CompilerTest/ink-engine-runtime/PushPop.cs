using System;
using System.Collections.Generic;

namespace Ink.Runtime
{
    internal enum PushPopType 
    {
        Tunnel,
        Function,
        FunctionEvaluationFromGame
    }
}

